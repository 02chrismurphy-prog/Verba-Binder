package com.verba.binder

import android.app.Service
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.WindowManager
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.ScrollView
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.BroadcastReceiver
import android.content.IntentFilter
import android.content.DialogInterface
import android.widget.EditText
import android.text.InputType
import android.graphics.Color
import android.widget.Toast
import org.json.JSONObject

class FloatingBinderService : Service() {
    private lateinit var wm: WindowManager
    private var bubble: View? = null
    private var panel: View? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (bubble == null) showBubble()
        return START_STICKY
    }

    private fun overlayType(): Int =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE

    private fun params(): WindowManager.LayoutParams =
        WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = 18; y = 220 }

    private fun showBubble() {
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val b = TextView(this).apply {
            text = "V"
            textSize = 20f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setBackgroundColor(Color.rgb(190, 48, 52))
            setPadding(18, 12, 18, 12)
            setOnClickListener { togglePanel() }
        }
        bubble = b
        wm.addView(b, params())
    }

    private fun togglePanel() {
        if (panel != null) {
            try { wm.removeView(panel) } catch (_: Exception) {}
            panel = null
            return
        }
        val outer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(12, 12, 12, 12)
            setBackgroundColor(Color.rgb(20, 27, 32))
        }
        val heading = TextView(this).apply {
            text = "VERBA • МОЇ ШВИДКІ КНОПКИ"
            setTextColor(Color.WHITE); textSize = 13f; setPadding(4,4,4,10)
        }
        outer.addView(heading)
        val scroll = ScrollView(this)
        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(list)
        outer.addView(scroll, LinearLayout.LayoutParams(260, 520))
        val saved = getSharedPreferences("verba_binder", Context.MODE_PRIVATE)
            .getString("binder_data", null)
        var count = 0
        try {
            if (saved != null) {
                val entries = JSONObject(saved).optJSONArray("entries")
                if (entries != null) {
                    for (i in 0 until entries.length()) {
                        val item = entries.optJSONObject(i) ?: continue
                        val title = item.optString("name", "Без назви")
                        val text = item.optString("text", "")
                        if (text.isNotBlank()) {
                            addCopyButton(list, title, text)
                            count++
                        }
                    }
                }
            }
        } catch (_: Exception) {}
        if (count == 0) {
            val empty = TextView(this).apply {
                text = "Поки немає власних текстів. Додай їх у головному вікні біндера."
                setTextColor(Color.LTGRAY); setPadding(8, 12, 8, 12)
            }
            list.addView(empty)
        }
        addCopyButton(list, "Швидка команда: /me", "/me ")
        addCopyButton(list, "Швидка команда: /do", "/do ")
        addCopyButton(list, "Швидка команда: /todo", "/todo ")
        addCustomEditor(list)
        addCopyButton(list, "Закрити панель", null)
        val p = params().apply { x = 78; y = 220 }
        panel = outer
        wm.addView(outer, p)
    }

    private fun addCopyButton(parent: LinearLayout, label: String, value: String?) {
        val button = Button(this).apply {
            text = label
            setOnClickListener {
                if (value == null) {
                    togglePanel()
                } else {
                    val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                    clipboard.setPrimaryClip(ClipData.newPlainText("Verba Binder", value))
                    Toast.makeText(this@FloatingBinderService,
                        "Скопійовано. Перейди в гру та встав текст.", Toast.LENGTH_SHORT).show()
                }
            }
        }
        parent.addView(button)
    }

    private fun addCustomEditor(parent: LinearLayout) {
        val title = TextView(this).apply {
            text = "МОЇ ШВИДКІ КНОПКИ"
            setTextColor(Color.LTGRAY); setPadding(4, 12, 4, 4)
        }
        parent.addView(title)
        val name = android.widget.EditText(this).apply {
            hint = "Назва кнопки"; setSingleLine(true); setTextColor(Color.WHITE)
        }
        val content = android.widget.EditText(this).apply {
            hint = "Текст команди"; setTextColor(Color.WHITE); minLines = 2
        }
        parent.addView(name)
        parent.addView(content)
        val save = Button(this).apply {
            text = "＋ Додати кнопку"
            setOnClickListener {
                val n = name.text.toString().trim()
                val t = content.text.toString().trim()
                if (n.isEmpty() || t.isEmpty()) {
                    Toast.makeText(this@FloatingBinderService, "Вкажи назву та текст.", Toast.LENGTH_SHORT).show()
                } else {
                    val prefs = getSharedPreferences("verba_binder", Context.MODE_PRIVATE)
                    val old = prefs.getString("overlay_custom", "") ?: ""
                    val line = android.util.Base64.encodeToString(
                        (n + "\n" + t).toByteArray(Charsets.UTF_8), android.util.Base64.NO_WRAP)
                    prefs.edit().putString("overlay_custom", if (old.isEmpty()) line else "$old|$line").apply()
                    Toast.makeText(this@FloatingBinderService, "Кнопку збережено. Перевідкрий панель.", Toast.LENGTH_SHORT).show()
                    name.setText(""); content.setText("")
                }
            }
        }
        parent.addView(save)
        val prefs = getSharedPreferences("verba_binder", Context.MODE_PRIVATE)
        val custom = prefs.getString("overlay_custom", "") ?: ""
        if (custom.isNotEmpty()) {
            custom.split("|").forEach { encoded ->
                try {
                    val decoded = String(android.util.Base64.decode(encoded, android.util.Base64.NO_WRAP), Charsets.UTF_8)
                    val parts = decoded.split("\n", limit = 2)
                    if (parts.size == 2) addCopyButton(parent, parts[0], parts[1])
                } catch (_: Exception) {}
            }
        }
    }

    override fun onDestroy() {
        try { bubble?.let { wm.removeView(it) } } catch (_: Exception) {}
        try { panel?.let { wm.removeView(it) } } catch (_: Exception) {}
        super.onDestroy()
    }
}
