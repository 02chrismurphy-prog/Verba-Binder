package com.verba.binder

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.webkit.JavascriptInterface
import android.content.Context
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.view.Gravity
import android.graphics.Color

class MainActivity : Activity() {
    private lateinit var web: WebView
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.rgb(11,15,18))
        }
        val top = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(12, 8, 12, 8)
            setBackgroundColor(Color.rgb(16,20,23))
        }
        val title = TextView(this).apply {
            text = "VERBA BINDER"
            textSize = 18f
            setTextColor(Color.WHITE)
            setPadding(8, 8, 8, 8)
        }
        val floatButton = Button(this).apply {
            text = "Плаваюча кнопка"
            setOnClickListener { enableFloating() }
        }
        top.addView(title, LinearLayout.LayoutParams(0, -2, 1f))
        top.addView(floatButton)
        web = WebView(this).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            webViewClient = WebViewClient()
            webChromeClient = WebChromeClient()
            addJavascriptInterface(BinderBridge(this@MainActivity), "AndroidBinder")
            loadUrl("file:///android_asset/index.html")
        }
        root.addView(top)
        root.addView(web, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
    }

    private fun enableFloating() {
        if (!Settings.canDrawOverlays(this)) {
            val intent = Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:$packageName"))
            startActivity(intent)
            return
        }
        startService(Intent(this, FloatingBinderService::class.java))
    }
}


class BinderBridge(private val context: Context) {
    @JavascriptInterface
    fun saveData(json: String) {
        context.getSharedPreferences("verba_binder", Context.MODE_PRIVATE)
            .edit().putString("binder_data", json).apply()
    }
}
