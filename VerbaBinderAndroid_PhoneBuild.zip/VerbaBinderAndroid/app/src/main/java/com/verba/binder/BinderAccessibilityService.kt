package com.verba.binder

import android.accessibilityservice.AccessibilityService
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.Toast

class BinderAccessibilityService : AccessibilityService() {
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    override fun onServiceConnected() {
        super.onServiceConnected()
        getSharedPreferences("verba_binder", Context.MODE_PRIVATE)
            .edit().putBoolean("accessibility_ready", true).apply()
    }

    override fun onDestroy() {
        getSharedPreferences("verba_binder", Context.MODE_PRIVATE)
            .edit().putBoolean("accessibility_ready", false).apply()
        super.onDestroy()
    }

    fun pasteClipboardIntoFocusedField(): Boolean {
        val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        if (!clipboard.hasPrimaryClip()) return false
        val root = rootInActiveWindow ?: return false
        val target = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT) ?: return false
        val ok = target.performAction(AccessibilityNodeInfo.ACTION_PASTE)
        if (!ok) Toast.makeText(this, "Гра не дозволила вставлення. Скористайся звичайною вставкою.", Toast.LENGTH_LONG).show()
        return ok
    }
}
